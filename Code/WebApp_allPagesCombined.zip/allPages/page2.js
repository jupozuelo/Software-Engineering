var bubbles = [];
var bath;
var sprites;

function preload() {
    sprites = loadAnimation('images/load.png', 'images/load1.png',
    'images/load2.png','images/load3.png', 'images/load4.png',
    'images/load5.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  sprites.frameDelay = 10;

  bath = createSprite(255, 320);
  bath.addAnimation('normal', sprites);

   bath.scale = 0.35;


  for (var i = 0; i < 10; i++) {
      var x = random(width);
      var y = random(height);
      bubbles.push(new Bubble(x, y));
  }

  next = new Clickable();
  next.locate(252, 115);
  next.resize(20, 20);
  next.text = ".";

  next.color = "#BCEFEF";
  next.stroke = "#aae1f9";


  next.onPress = function() {
      this.color = "#aae1f9";
  }

  next.onRelease = function() {
      this.color = "#aae1f9";
      window.open('index3.html', "_self");
  }
}

function Bubble(x, y) {
    this.x = x;
    this.y = y;

    this.display = function() {
        stroke(255);
        fill(232, 247, 250);
        ellipse(this.x, this.y, 48, 48);
    }

    this.move = function() {
        this.x = this.x + random(-1, 1);
        this.y = this.y + random(-1, 1);
    }
}

function draw() {
 background(255);
 textFont('Chalkboard');

 drawSprites();

  for (var i = 0; i < bubbles.length; i++) {
      bubbles[i].move();
      bubbles[i].display();
  }

  push();
  strokeWeight(10);

  stroke("#BCEFEF");
  noFill();
  arc(263, 100, 200, 150, PI, TWO_PI);

  stroke("#BCEFEF");
  noFill();
  arc(263, 109, 150, 100, PI, TWO_PI);

  stroke("#BCEFEF");
  noFill();
  arc(263, 118, 100, 50, PI, TWO_PI);

  stroke("#BCEFEF");
  noFill();
  ellipse(262, 125, 10, 10);

  pop();

  fill(0);
  textSize(30);
  text("Searching for chosen bath", 100, 200);

  next.draw();

}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
