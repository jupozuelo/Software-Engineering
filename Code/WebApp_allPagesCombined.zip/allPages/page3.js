var bathFound;
var bath;
var sprites;

function preload() {
    bath = loadImage('images/bathFound.png');
    sprites = loadAnimation('images/shape.png')
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  //bathFound = createSprite(270, 350);
  bathFound = createSprite(260, 280);
  bathFound.addAnimation('normal', sprites);
  bathFound.scale = 0.65;

  next = new Clickable();
  next.locate(307, 230);
  next.resize(5, 5);
  next.text = " ";

  next.color = "#aae1f9";
  next.stroke = "#aae1f9";


  next.onPress = function() {
      this.color = "#aae1f9";
  }

  next.onRelease = function() {
      this.color = "#aae1f9";
      window.open('index4.html', "_self");
  }
}

function draw() {
    background(255);
    textFont('Chalkboard');

    bathFound.rotation += 1.5;
    drawSprites();

    image(bath, 165, 225, 180, 140);
    //image(bath, CENTER, CENTER, 180, 140);

    fill(0);
    textSize(50);
    text("Bath found!", 130, 65);

    next.draw();

}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
