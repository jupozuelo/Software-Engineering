var bubbles = [];
var bathLoad;

function setup() {
  createCanvas(windowWidth, windowHeight);
  bathLoad = createSprite(220, 420);
  bathLoad.addAnimation('normal', 'images/load.png', 'images/load1.png',
                    'images/load2.png','images/load3.png',
                    'images/load4.png','images/load5.png');

   bathLoad.scale = 0.35;

  for (var i = 0; i < 10; i++) {
      var x = random(width);
      var y = random(height);
      bubbles.push(new Bubble(x, y));
  }
}

function draw() {
 background(255);
 textFont('Chalkboard');

 drawSprites();

  for (var i = 0; i < bubbles.length; i++) {
      bubbles[i].move();
      bubbles[i].display();
  }

  push();
  strokeWeight(10);

  stroke(170, 225, 249);
  noFill();
  arc(233, 200, 200, 150, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  arc(233, 209, 150, 100, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  arc(233, 218, 100, 50, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  ellipse(232, 225, 10, 10);

  pop();

  fill(0);
  textSize(30);
  text("Searching for chosen bath", 70, 300);

}
