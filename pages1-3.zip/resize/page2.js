var bubbles = [];
var bath;
var sprites;

function preload() {
    sprites = loadAnimation('images/load.png', 'images/load1.png',
    'images/load2.png','images/load3.png', 'images/load4.png',
    'images/load5.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  sprites.frameDelay = 10;

  bath = createSprite(220, 420);
  bath.addAnimation('normal', sprites);

   bath.scale = 0.35;


  for (var i = 0; i < 10; i++) {
      var x = random(width);
      var y = random(height);
      bubbles.push(new Bubble(x, y));
  }

  next = new Clickable();
  next.locate(222, 215);
  next.resize(20, 20);
  next.text = ".";

  next.color = "#aae1f9";
  next.stroke = "#aae1f9";


  next.onPress = function() {
      this.color = "#0000ff";
  }

  next.onRelease = function() {
      this.color = "#aae1f9";
      window.open('index3.html', "_self");
  }
}

function draw() {
 background(255);
 textFont('Chalkboard');

 drawSprites();

  for (var i = 0; i < bubbles.length; i++) {
      bubbles[i].move();
      bubbles[i].display();
  }

  push();
  strokeWeight(10);

  stroke(170, 225, 249);
  noFill();
  arc(233, 200, 200, 150, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  arc(233, 209, 150, 100, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  arc(233, 218, 100, 50, PI, TWO_PI);

  stroke(170, 225, 249);
  noFill();
  ellipse(232, 225, 10, 10);

  pop();

  fill(0);
  textSize(30);
  text("Searching for chosen bath", 70, 300);

  next.draw();

}
