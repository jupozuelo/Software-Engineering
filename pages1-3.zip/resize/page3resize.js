var img;

function setup() {
  createCanvas(windowWidth, windowHeight);
  img = loadImage("bath_found.png");
}

function draw() {
 background(255);
 image(img, 100, 200, 300, 300);
 textFont('Chalkboard');

  fill(0);
  textSize(50);
  text("Bath found!", 130, 130);
}
