var bath1;
var bath2;
var bath3;
var addMore;
var sprites;
var bathSprite;

function preload() {
    sprites = loadAnimation('images/1.png', 'images/2.png',
    'images/3.png', 'images/4.png', 'images/5.png', 'images/6.png',
    'images/7.png', 'images/8.png', 'images/9.png');
}

function setup() {
    createCanvas(windowWidth, windowHeight);
    bathSprite = createSprite(370, 100);
    bathSprite.addAnimation('normal', sprites);
    bathSprite.scale = 0.5;


    // upstairs bathroom button
    bath1 = new Clickable();
    bath1.locate(60, 190);
    bath1.resize(380, 50);

    bath1.color = "#aae1f9";
    bath1.stroke = "#aae1f9";
    bath1.textColor = "#ffffff";
    bath1.textFont = "Chalkboard";
    bath1.textSize = "18;"
    bath1.text = "Upstairs";

    /*bath1.onHover = function() {
        cursor(HAND);
    }*/

    bath1.onPress = function() {
        this.color = "#0000ff";
    }

    bath1.onRelease = function() {
        this.color = "#aae1f9";
        window.open('index2.html');
    }

    // downstairs bath
    bath2 = new Clickable();
    bath2.locate(60, 300);
    bath2.resize(380, 50);
    bath2.color = "#aae1f9";
    bath2.stroke = "#aae1f9";
    bath2.textColor = "#ffffff";
    bath2.textFont = "Chalkboard";
    bath2.textSize = "18;"
    bath2.text = "Downstairs";

    bath2.onPress = function() {
        this.color = "#0000ff";
    }

    bath2.onRelease = function() {
        this.color = "#aae1f9";
        window.open('index2.html');
    }

    // guest bath
    bath3 = new Clickable();
    bath3.locate(60, 410);
    bath3.resize(380, 50);

    bath3.color = "#aae1f9";
    bath3.stroke = "#aae1f9";
    bath3.textColor = "#ffffff";
    bath3.textFont = "Chalkboard";
    bath3.textSize = "18;"
    bath3.text = "Guest Room";


    bath3.onPress = function() {
        this.color = "#0000ff";
    }

    bath3.onRelease = function() {
        this.color = "#aae1f9";
        window.open('index2.html');
    }

    // add more baths
    addMore = new Clickable();
    addMore.locate(60, 520);
    addMore.resize(380, 50);

    addMore.color = "#aae1f9";
    addMore.stroke = "#aae1f9";
    addMore.textColor = "#ffffff";
    addMore.textFont = "Chalkboard";
    addMore.textSize = "18;"
    addMore.text = "Add more";


    addMore.onPress = function() {
        this.color = "#0000ff";
    }

    addMore.onRelease = function() {
        this.color = "#aae1f9";
    }


}



function draw() {
    background(255);
    textFont('Chalkboard');

    drawSprites();

    fill(0);
    textSize(30);
    text("Choose a bath...", 40, 160);


    bath1.draw();

    bath2.draw();

    bath3.draw();

    addMore.draw();

}
