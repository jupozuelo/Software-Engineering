var bathFound;
var bath;
var sprites;

function preload() {
    bath = loadImage('images/bathFound.png');
    sprites = loadAnimation('images/shape.png')
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  bathFound = createSprite(270, 350);
  bathFound.addAnimation('normal', sprites);
  bathFound.scale = 0.65;
}

function draw() {
    background(255);
    textFont('Chalkboard');

    bathFound.rotation += 1.5;
    drawSprites();

    image(bath, 180, 295, 180, 140);

    fill(0);
    textSize(50);
    text("Bath found!", 130, 100);

}
